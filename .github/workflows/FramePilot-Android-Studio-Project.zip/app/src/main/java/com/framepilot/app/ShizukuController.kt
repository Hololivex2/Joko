package com.framepilot.app

import rikka.shizuku.Shizuku

class ShizukuController(private val context: Context, private val repository: SettingsRepository) {
    fun enableImmersiveMode(packageName: String): Result<String> {
        // Whitelisted safe command execution only
        val cmd = "settings put global policy_control immersive.full=$packageName"
        return executeSafeShell(cmd)
    }
}