package com.framepilot.app

import android.content.Context
import android.content.pm.PackageManager

object AppPicker {
    fun getLaunchableApps(context: Context): List<AppInfo> {
        val pm = context.packageManager
        // Query launchable packages
        return ...
    }
}