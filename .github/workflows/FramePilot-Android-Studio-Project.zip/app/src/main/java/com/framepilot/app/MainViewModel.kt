package com.framepilot.app

import androidx.lifecycle.AndroidViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val _shizukuState = MutableStateFlow<ShizukuState>(ShizukuState.NotConnected)
    val shizukuState: StateFlow<ShizukuState> = _shizukuState.asStateFlow()

    private val _refreshRate = MutableStateFlow(60)
    val refreshRate: StateFlow<Int> = _refreshRate.asStateFlow()
}