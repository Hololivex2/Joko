package com.framepilot.app

import android.opengl.GLES30

class FrameRenderer {
    // Fragment Shader: Motion Blend Interpolation
    private const val FRAGMENT_SHADER = """#version 300 es
        precision mediump float;
        uniform sampler2D uTexturePrev;
        uniform sampler2D uTextureCurr;
        uniform float uBlendFactor;
        in vec2 vTexCoord;
        out vec4 fragColor;
        void main() {
            fragColor = mix(texture(uTexturePrev, vTexCoord), texture(uTextureCurr, vTexCoord), uBlendFactor);
        }
    """
}