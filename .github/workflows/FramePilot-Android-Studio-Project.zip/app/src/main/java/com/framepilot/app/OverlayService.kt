package com.framepilot.app

import android.app.Service
import android.view.WindowManager

class OverlayService : Service(), FrameCaptureCallback {
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIFICATION_ID, createNotification())
        initOverlayHud()
        return START_STICKY
    }
}