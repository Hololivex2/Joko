package com.framepilot.app

import android.media.ImageReader
import android.media.projection.MediaProjection

class ProjectionController(
    private val context: Context,
    private val mediaProjection: MediaProjection,
    private val qualityMode: QualityMode,
    private val callback: FrameCaptureCallback
) {
    fun startCapture() { ... }
    fun stopCapture() { ... }
}